<?php

namespace Shop\Db;
use PDO;
class Db
{
    public static $servername = "localhost";
    public static  $username = "root";
    public  static $password ="";
    public  static $dbname = "shop";
    static  function connect()
    {
        $conn = new PDO("mysql:host=".self::$servername.";dbname=".self::$dbname, self::$username, self::$password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    }
}