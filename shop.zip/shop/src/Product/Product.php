<?php

namespace Shop\Product;
use Shop\Db\Db;
use PDO;

class Product
{
    public $id = null;
    public $title = null;
    public $picture = null;
    public $description = null;
    public $qty = null;
    public $mrp = null;
    public $special_price = null;
    public $soft_delete = null;
    public $is_active = null;
    public $created_at = null;
    public $modified_at = null;
    public $short_description = null;
    public $category = null;
    public $brand = null;
    public $cost = null;
    public $is_new = null;
    public $conn = null;

    function __construct()
    {
        $this->conn = Db::connect();
    }

    function all()
    {

        $query = ("SELECT *  FROM products");
        $sth = $this->conn->prepare($query);
        $sth->execute();
        return $sth->fetchAll(PDO::FETCH_ASSOC);

    }

    function getNew($number=6)
    {

        $query = ("SELECT * FROM `products` WHERE is_new=1 LIMIT 0,$number");
        $sth = $this->conn->prepare($query);
        $sth->execute();
        return $sth->fetchAll(PDO::FETCH_ASSOC);

    }

    function store($data)
    {
        $this->build($data);
                                $query="INSERT INTO `products` (
                          `title`,
                          `picture`,
                          `description`,
                            `qty`, 
                            `mrp`, 
                            `special_price`, 
                            `soft_delete`, 
                            `is_active`, 
                            `created_at`,
                             `modified_at`,
                              `short_description`, 
                              `category`,
                               `brand`,
                              `cost`,
                               `is_new`) VALUES (
                               :title,
                                :picture, 
                                :description, 
                                :qty, 
                                :mrp, 
                                :special_price,
                                 NULL,
                                 NULL,
                                  NULL,
                                   NULL, 
                                   :short_description,
                                    :category, 
                                    :brand,
                                    :cost,
                                    :is_new);";
        $sth = $this->conn->prepare($query);
        $sth->bindparam(':title',$this->title);
        $sth->bindParam(':picture',$this->picture);
        $sth->bindparam(':description',$this->description);
        $sth->bindparam(':qty',$this->qty);
        $sth->bindparam(':mrp',$this->mrp);
        $sth->bindparam(':special_price',$this->special_price);
        $sth->bindparam(':short_description',$this->short_description);
        $sth->bindparam(':category',$this->category);
        $sth->bindparam(':brand',$this->brand);
        $sth->bindparam(':cost',$this->cost);
        $sth->bindparam(':is_new',$this->is_new);
        $result=$sth->execute();
        return $result;
    }

    function  show($id)
    {
        $query="select * from products where id=:id";
        $sth = $this->conn->prepare($query);
        $sth->bindparam(':id',$id);
        $sth->execute();
        $products=$sth->fetch(PDO::FETCH_ASSOC);
        return $products;
    }
    function delete($id)
    {
        $query="DELETE FROM `products` WHERE `products`.`id` = :id";
        $sth = $this->conn->prepare($query);
        $sth->bindparam(':id',$id);
        $result=$sth->execute();
        return $result;
    }
    function update($data)

    {
        $this->build($data);
                                                                    $query="UPDATE `products` 
                                                            SET `title` = :title,
                                                            `picture`=:picture,
                                                             `short_description` = :short_description ,
                                                             `description` = :description,
                                                             `mrp`=:mrp,
                                                             `cost`=:cost,
                                                             `special_price`= :special_price,
                                                             `qty`=:qty,
                                                             `category`=:category,
                                                             `brand`=:brand,
                                                             `is_new`=:is_new
                                                             WHERE `products`.`id` = :id;";
        $sth = $this->conn->prepare($query);
        $sth->bindparam(':id',$this->id);
        $sth->bindparam(':title',$this->title);
        $sth->bindParam(':picture',$this->picture);
        $sth->bindparam(':short_description',$this->short_description);
        $sth->bindparam(':description',$this->description);
        $sth->bindparam(':mrp',$this->mrp);
        $sth->bindparam(':cost',$this->cost);
        $sth->bindparam(':special_price',$this->special_price);
        $sth->bindparam(':qty',$this->qty);
        $sth->bindparam(':category',$this->category);
        $sth->bindparam(':brand',$this->brand);
        $sth->bindparam(':is_new',$this->is_new);

        $result=$sth->execute();
        return $result;
    }
    private function build($data)
    {
        if(array_key_exists('id',$data)&&!empty($data['id']))
        {
            $this->id=$data['id'];
        }
        $this->title=$data['title'];
        $this->picture=$data['picture'];
        $this->description=$data['description'];
        $this->short_description=$data['short_description'];
        $this->qty=$data['qty'];
        $this->mrp=$data['mrp'];
        $this->special_price=$data['special_price'];
        $this->category=$data['category'];
        $this->brand=$data['brand'];
        $this->cost=$data['cost'];
        $this->is_new=$data['is_new'];
    }
}