<?php

namespace Shop\Cart;
use Shop\Product;
use Shop\Db\Db;
use PDO;
class Cart
{
    public $id = null;
    public $sid = null;
    public $product_id = null;
    public $product_title = null;
    public $picture = null;
    public $qty = null;
    public $unit_price = null;
    public $total_price = null;
    public $created_at = null;
    public $modified_at = null;

    function __construct()
    {
        $this->conn = Db::connect();
    }

    function all($sid)
    {
        $query = "select * from carts where `sid`=:sid";
        $sth = $this->conn->prepare($query);
        $sth->bindparam(':sid', $sid);
        $sth->execute();
        $carts = $sth->fetchAll(PDO::FETCH_ASSOC);
        return $carts;

    }

    function store($data)
    {

            $this->build($data);
            if($this->is_already_in_cart($data['sid'],$data['product_id'])){
               $result= $this->updatebyqty($data['qty'],$data['sid'],$data['product_id']);
               return $result;

            }

                                        $query = "INSERT INTO `carts` ( `sid`, 
`product_id`,
 `product_title`,
  `picture`, 
  `qty`,
   `unit_price`, 
   `total_price`) VALUES ( :sid,
 :product_id,
  :product_id,
   :picture,
    :qty, :unit_price, :total_price);";
            $sth = $this->conn->prepare($query);
            $sth->bindparam(':sid', $this->sid);
            $sth->bindparam(':product_id',  $this->product_id);
            $sth->bindparam(':product_title',$this->product_title);
            $sth->bindparam(':picture',  $this->picture);
            $sth->bindparam(':qty', $this->qty);
            $sth->bindparam(':unit_price',$this->unit_price);
            $sth->bindparam(':total_price', $this->total_price);

            $result = $sth->execute();
            return $result;
        }
        public function updatebyqty($qty,$sid,$product_id)
        {


            $query = "select * from carts where `sid`=:sid";
            $sth = $this->conn->prepare($query);
            $sth->bindparam(':sid', $sid);
            $sth->execute();
            $carts = $sth->fetchAll(PDO::FETCH_ASSOC);
            $final_qty=  $qty;
            $total_price= $final_qty * $carts['unit_price'];

                                        $query="UPDATE `carts` SET 
                            `qty` =:qty ,
                            `total_price` =:total_price WHERE `carts`.`sid` = :sid
                                                              and `carts`.`product_id`=:product_id;";
            $sth = $this->conn->prepare($query);

            $sth->bindparam(':sid', $sid);
            $sth->bindparam(':product_id',$product_id);

            $sth->bindparam(':qty',$final_qty);

            $sth->bindparam(':total_price',$total_price);
            $result=$sth->execute();
            return $result;


        }
        private function is_already_in_cart($sid,$product_id){
            $query = "select * from carts where `sid`=:sid and `product_id`=:product_id";
            $sth = $this->conn->prepare($query);
            $sth->bindparam(':sid', $sid);
            $sth->bindparam(':product_id', $product_id);
            $sth->execute();
            $carts = $sth->fetch(PDO::FETCH_ASSOC);
            if($carts){
                return true;
            }
            else{
                return false;
            }

        }

        function delete($product_id)
        {
            if ($_SESSION['loggedin'] == true) {
                {
                    $query = "DELETE FROM `carts` WHERE `carts`.`product_id` = :product_id and `carts`.`sid` = :sid";
                    $sth = $this->conn->prepare($query);
                    $sth->bindparam(':product_id', $product_id);
                    $sth->bindparam(':sid', $_SESSION['loggedin']);
                    $result = $sth->execute();
                    return $result;
                }
            }
            else{

                $query = "DELETE FROM `carts` WHERE `carts`.`product_id` = :product_id and `carts`.`sid` = :sid";
                $sth = $this->conn->prepare($query);
                $sth->bindparam(':product_id', $product_id);
                $sth->bindparam(':sid', $_SESSION['guest_user']);
                $result = $sth->execute();
                return $result;
            }
        }


    private function build($data)
    {
        $this->sid= $data['sid'];
        $this->product_id= $data['product_id'];
        $this->product_title= $data['product_title'];
        $this->picture= $data['picture'];
        $this->qty= $data['qty'];
        $this->unit_price= $data['unit_price'];
        $this->total_price= $data['total_price'];
    }

}