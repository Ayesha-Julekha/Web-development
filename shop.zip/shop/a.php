
function  show($id)
{
$query="select * from carts where id=:id";
$sth = $this->conn->prepare($query);
$sth->bindparam(':id',$id);
$sth->execute();
$products=$sth->fetch(PDO::FETCH_ASSOC);
return $products;
}
function delete($id)
{
$query="DELETE FROM `carts` WHERE `carts`.`id` = :id";
$sth = $this->conn->prepare($query);
$sth->bindparam(':id',$id);
$result=$sth->execute();
return $result;
}
function update($data)

{
$this->build($data);
$query="UPDATE `carts` SET `sid`=:sid,
`product_id`=:product_id,
`product_title`=:product_title,
`picture`=:picture,
`qty` =:qty ,
`unit_price` =:unit_price ,
`total_price` =:total_price WHERE `carts`.`id` = :id;";
$sth = $this->conn->prepare($query);
$sth->bindparam(':id',$this->id);
$sth->bindparam(':sid', $this->sid);
$sth->bindparam(':product_id',$this->product_id);
$sth->bindparam(':product_title', $this->product_title);
$sth->bindparam(':qty',$this->qty);
$sth->bindparam(':unit_price',$this->unit_price);
$sth->bindparam(':total_price',$this->total_price);
$result=$sth->execute();
return $result;

}
private function is_already_in_cart($id,$product_id)
{
$query="select * from carts where `id`=:id and `product_id`=:product_id";
$sth = $this->conn->prepare($query);
$sth->bindparam(':id',$id);
$sth->bindparam(':product_id',$product_id);
$sth->execute();
$product=$sth->fetch(PDO::FETCH_ASSOC);
if($product) {
return true;
}
else{
return false;
}
}
private function build($data)
{
if (array_key_exists('id', $data) && !empty($data['id'])) {
$this->id = $data['id'];
}
$this->sid=$data['sid'];
$this->product_id=$data['product_id'];
$this->product_title=$data['product_title'];
$this->picture=$data['picture'];
$this->qty=$data['qty'];
$this->unit_price=$data['unit_price'];
$this->total_price=$data['total_price'];
}
function  show($id)
{
$query="select * from carts where id=:id";
$sth = $this->conn->prepare($query);
$sth->bindparam(':id',$id);
$sth->execute();
$products=$sth->fetch(PDO::FETCH_ASSOC);
return $products;
}
function delete($id)
{
$query="DELETE FROM `carts` WHERE `carts`.`id` = :id";
$sth = $this->conn->prepare($query);
$sth->bindparam(':id',$id);
$result=$sth->execute();
return $result;
}
function update($data)

{
$this->build($data);
$query="UPDATE `carts` SET `sid`=:sid,
`product_id`=:product_id,
`product_title`=:product_title,
`picture`=:picture,
`qty` =:qty ,
`unit_price` =:unit_price ,
`total_price` =:total_price WHERE `carts`.`id` = :id;";
$sth = $this->conn->prepare($query);
$sth->bindparam(':id',$this->id);
$sth->bindparam(':sid', $this->sid);
$sth->bindparam(':product_id',$this->product_id);
$sth->bindparam(':product_title', $this->product_title);
$sth->bindparam(':qty',$this->qty);
$sth->bindparam(':unit_price',$this->unit_price);
$sth->bindparam(':total_price',$this->total_price);
$result=$sth->execute();
return $result;

}
private function is_already_in_cart($id,$product_id)
{
$query="select * from carts where `id`=:id and `product_id`=:product_id";
$sth = $this->conn->prepare($query);
$sth->bindparam(':id',$id);
$sth->bindparam(':product_id',$product_id);
$sth->execute();
$product=$sth->fetch(PDO::FETCH_ASSOC);
if($product) {
return true;
}
else{
return false;
}
}
private function build($data)
{
if (array_key_exists('id', $data) && !empty($data['id'])) {
$this->id = $data['id'];
}
$this->sid=$data['sid'];
$this->product_id=$data['product_id'];
$this->product_title=$data['product_title'];
$this->picture=$data['picture'];
$this->qty=$data['qty'];
$this->unit_price=$data['unit_price'];
$this->total_price=$data['total_price'];
}