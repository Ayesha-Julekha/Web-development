<?php
include_once($_SERVER["DOCUMENT_ROOT"]."/shop/bootstrap.php");
use Shop\Cart\Cart;


$data=$_POST;
$id=$_POST['id'];

$qty=$_POST['qty'];

$total_price=$_POST['total_price'];


$cart=new Cart();


$result=$cart->updatebyqty($data);


header("location:index.php");