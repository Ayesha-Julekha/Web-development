<?php
include_once($_SERVER["DOCUMENT_ROOT"]."/shop/bootstrap.php");
use Shop\Cart\Cart;


$cart=new Cart();

$cats=$cart->delete($_GET['id']);

header("location:index.php");