<?php
include_once($_SERVER["DOCUMENT_ROOT"]."/shop/bootstrap.php");
use Shop\Cart\Cart;
$data=$_POST;

$target_file = $_FILES['picture']['tmp_name'];
$filename = time()."_".str_replace(' ','-',$_FILES['picture']['name']);
$dest_file = $_SERVER['DOCUMENT_ROOT'].'/shop/uploads/'.$filename;
$is_uploaded = move_uploaded_file($target_file, $dest_file);

if($is_uploaded){
    $data['picture'] = $filename;
}else{
    $data['picture']  = "";
}





$sid=$_POST['sid'];

$product_id=$_POST['product_id'];

$product_title=$_POST['product_title'];

$qty=$_POST['qty'];

$unit_price=$_POST['unit_price'];

$total_price=$_POST['total_price'];

$cart=new Cart();

$result=$cart->store($data);


header("location:index.php");