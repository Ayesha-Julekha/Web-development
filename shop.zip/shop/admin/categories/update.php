<?php
$id=$_POST['id'];
$name=$_POST['name'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";
$conn = new PDO("mysql:host=$servername;dbname=shop", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$query="UPDATE `categories` 
SET `name` = :name
WHERE `categories`.`id` = :id";
$sth = $conn->prepare($query);
$sth->bindparam(':id',$id);
$sth->bindparam(':name',$name);
$result=$sth->execute();
header("location:index.php");