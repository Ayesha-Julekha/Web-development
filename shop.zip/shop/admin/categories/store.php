<?php
$name=$_POST['name'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";
$conn = new PDO("mysql:host=$servername;dbname=shop", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$query="INSERT INTO `categories` (`name`, `soft_delete`, `modified_at`, `is_draft`, `created_at`) VALUES ( :name, NULL, NULL, NULL, NULL);";
$sth = $conn->prepare($query);
$sth->bindparam(':name',$name);
$result=$sth->execute();
print_r($result);
header("location:index.php");