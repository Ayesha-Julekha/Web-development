<?php
include_once($_SERVER["DOCUMENT_ROOT"]."/shop/bootstrap.php");


use Shop\Product\Product;


$data=$_POST;

$id=$_POST['id'];

$title=$_POST['title'];
$prev_picture_name = $_POST['prev_picture_name'];

$short_description=$_POST['short_description'];
$description=$_POST['description'];
$mrp=$_POST['mrp'];
$cost=$_POST['cost'];
$special_price=$_POST['special_price'];
$qty=$_POST['qty'];
$category=$_POST['category'];
$brand=$_POST['brand'];
$is_new=$_POST['is_new'];


$is_uploaded = false;
if($_FILES['picture']['size'] > 0){
    $target_file = $_FILES['picture']['tmp_name'];
    $filename = time()."_".str_replace(' ','-',$_FILES['picture']['name']);
    $dest_file = $_SERVER['DOCUMENT_ROOT'].'/shop/uploads/'.$filename;
    $is_uploaded = move_uploaded_file($target_file, $dest_file);
}
if($is_uploaded){
    $data['picture'] = $filename;
}else{
    $data['picture'] = $prev_picture_name;
}

$product=new Product();


$result=$product->update($data);


header("location:index.php");