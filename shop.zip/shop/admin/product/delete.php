<?php
include_once($_SERVER["DOCUMENT_ROOT"]."/shop/bootstrap.php");
use Shop\Product\Product;


$product=new Product();

$products=$product->delete($_GET['id']);



header("location:index.php");