<?php
include_once($_SERVER["DOCUMENT_ROOT"]."/shop/bootstrap.php");

use Shop\Product\Product;


$data=$_POST;


$target_file = $_FILES['picture']['tmp_name'];
$filename = time()."_".str_replace(' ','-',$_FILES['picture']['name']);
$dest_file = $_SERVER['DOCUMENT_ROOT'].'/shop/uploads/'.$filename;
$is_uploaded = move_uploaded_file($target_file, $dest_file);

if($is_uploaded){
    $data['picture'] = $filename;
}else{
    $data['picture']  = "";
}

$title=$_POST['title'];
$description=$_POST['description'];
$qty=$_POST['qty'];
$mrp=$_POST['mrp'];
$special_price=$_POST['special_price'];
$short_description=$_POST['short_description'];
$category=$_POST['category'];
$brand=$_POST['brand'];
$cost=$_POST['cost'];
$is_new=$_POST['is_new'];

$product=new Product();


$result=$product->store($data);






header("location:index.php");