<?php
$id=$_POST['id'];
$customer_id=$_POST['customer_id'];
$product_id=$_POST['product_id'];
$qty=$_POST['qty'];
$category_id=$_POST['category_id'];
$customer_email=$_POST['customer_email'];
$customer_phone=$_POST['customer_phone'];
$total_price=$_POST['total_price'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";



$conn = new PDO("mysql:host=$servername;dbname=shop", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


$query="UPDATE `orders` SET `customer_id`=:customer_id,
`product_id`=:product_id,
`qty`=:qty,
`category_id`=:category_id;
`customer_email`=:customer_email,
`customer_phone`=:customer_phone,
`total_price`=:total_price
 WHERE `orders`.`id` = :id;";
$sth = $conn->prepare($query);

$sth->bindparam(':id',$id);

$sth->bindparam(':customer_id',$customer_id);
$sth->bindparam(':product_id',$product_id);
$sth->bindparam(':qty',$qty);
$sth->bindparam(':category_id',$category_id);
$sth->bindparam(':customer_email',$customer_email);
$sth->bindparam(':customer_phone',$customer_phone);
$sth->bindparam(':total_price',$total_price);

$result=$sth->execute();
header("location:index.php");