<?php
$name=$_POST['name'];
$email=$_POST['email'];
$password1=$_POST['password1'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";
$conn = new PDO("mysql:host=$servername;dbname=shop", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$query="INSERT INTO `admins` (
`name`,
 `email`, 
 `password`, 
 `soft_delete`, 
 `is_draft`,
  `created_at`, 
  `modifies_at`) VALUES (:name, :email, :password1, NULL, NULL, NULL, NULL);";
$sth = $conn->prepare($query);
$sth->bindparam(':name',$name);
$sth->bindparam(':email',$email);
$sth->bindparam(':password1',$password1);
$result=$sth->execute();
print_r($result);
header("location:index.php");