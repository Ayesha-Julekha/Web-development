<?php
$id=$_GET['id'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";
$conn = new PDO("mysql:host=$servername;dbname=shop", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$query="DELETE FROM `admins` WHERE `admins`.`id` = :id";
$sth = $conn->prepare($query);
$sth->bindparam(':id',$id);
$result=$sth->execute();
header("location:index.php");