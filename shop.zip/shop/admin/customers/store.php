<?php
$name=$_POST['name'];
$email=$_POST['email'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";
$conn = new PDO("mysql:host=$servername;dbname=shop", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$query="INSERT INTO `customers` (
`name`,
 `email`,  
  `created_at`, 
  `modified_at`) VALUES (:name, :email, NULL, NULL);";
$sth = $conn->prepare($query);
$sth->bindparam(':name',$name);
$sth->bindparam(':email',$email);

$result=$sth->execute();
print_r($result);
header("location:index.php");