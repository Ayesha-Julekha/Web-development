<?php
$id=$_POST['id'];

$name=$_POST['name'];
$email=$_POST['email'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";
$conn = new PDO("mysql:host=$servername;dbname=shop", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$query="UPDATE `customers` 
SET `name` = :name,
`email`=:email
WHERE `customers`.`id` = :id";
$sth = $conn->prepare($query);

$sth->bindparam(':id',$id);
$sth->bindparam(':name',$name);
$sth->bindparam(':email',$email);
$result=$sth->execute();
header("location:index.php");