<!doctype html>
<html lang="en" xmlns="http://www.w3.org/1999/html" xmlns="http://www.w3.org/1999/html">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../lib/css/style.css">

    <title>Product</title>
</head>
<body background="images/s14.jpg">

<header>
    <div class="container">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">
            <div id="font1"><strong>AYESHA'S Glamorous Shop</strong></div>
        </a>
        <button class="navbar-toggler"
                type="button" data-toggle="collapse"
                data-target="#menu"
                aria-controls="menu"
                aria-expanded="false"
                aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="menu">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#home">Home<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#products">HIJAB</a>
                </li>


            </ul>
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="cart.php">Shop
                    </a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="about_us">About Us
                    </a>
                </li>

            </ul>

        </div>
    </nav>


<?php
//connect to database
include_once($_SERVER["DOCUMENT_ROOT"]."/shop/bootstrap.php");
use Shop\Product\Product;


$product=new Product();

$products=$product->show($_GET['id']);

//print_r($sponser);
?>
<section class="ftco-section bg-light">
<form method="post" action="addtocart.php">
        <div class="row">
            <div class="col-lg col-lg-6 col-lg-3 ftco-animate">
                <div class="image-prod"><div class="img">
                        <img src="<?=UPLOADS?><?php echo $products['picture']?>">
                    </div>
                </div>
                <div>Id:<input type="hidden" id="id" name="id" value="<?php echo $products['id']?>"></div>
                <div class="product">

                    <h3>
                    <div class="text">
                         <?php echo "Product Name: ".$products['title'];?>
                    </div>
                    </h3>

                </div>
                <div class="text">
                    <h4>
                    <?php

                    if($products['special_price']>0)
                    {
                        echo "Product Price :<strike>". $products['mrp']."</strike>";
                        echo "&nbsp";
                        echo $products['special_price'] ;
                    }
                    else {
                        echo "Product Price :".$products['mrp'];
                    }
                    ?>
                        <div>Quantity:<input type="text"  id="qty" name="qty" value="1"></div>
                    </h4>
                </div>


            </div>


        </div>
    <div class="row">
        <div class="col-md-6 col-md-6 col-md-3">
            <div class="text-dark">
                <h5>
                    <?php echo "About : ".$products['description'];?>
                </h5>
            </div>
            <div class="text-dark">
                <h6>
                    <?php echo $products['short_description'];?>
                </h6>
            </div>
            <div class="text-dark">
                <h6>
                    <?php echo "Brand : ".$products['brand'];?>

                </h6>
            </div>
        </div>
    </div>

    <div class="col-xs-4 text-right">
<button type="submit" class="btn btn-secondary">Add to cart</button>
    </div>
</form>
</section>

</div>
</header>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="../lib/js/bootstrap.min.js"></script>
</body>
</html>



