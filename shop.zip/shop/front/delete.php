<?php

include_once($_SERVER["DOCUMENT_ROOT"]."/shop/bootstrap.php");
use Shop\Cart\Cart;

use Shop\Product;
$cart=new Cart();
$result=$cart->delete($_GET['product_id']);
if($result)
{ header("location:cart.php");
}