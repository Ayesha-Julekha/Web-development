<?php

include_once($_SERVER["DOCUMENT_ROOT"]."/shop/bootstrap.php");
use Shop\Cart\Cart;

use Shop\Product;
$cart=new Cart();
if($_SESSION['loggedin']==true) {
    $result = $cart->updatebyqty($_POST['qty'], $_POST['product_id'], $_SESSION['loggedin']);
}
else
{
    $result = $cart->updatebyqty($_POST['qty'], $_POST['product_id'], $_SESSION['loggedin']);
}

if($result)
{
    header("location:cart.php");
}