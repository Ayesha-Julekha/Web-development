<?php
//connect to database
include_once($_SERVER["DOCUMENT_ROOT"]."/shop/bootstrap.php");
use Shop\Product\Product;
use Shop\Cart\Cart;
session_start();
$product=new Product();

$product=$product->show($_POST['id']);
$data=$_POST;
if($_SESSION['loggedin']==true) {
    $data['sid'] = $_SESSION['loggedin'];
}
else{
    $data['sid'] = $_SESSION['guest_user'];
}
$data['product_id']=$product['id'];
$data['product_title']=$product['title'];
$data['picture']=$product['picture'];
$data['qty']=$_POST['qty'];
$data['unit_price']=$product['mrp'];
$data['total_price']=$product['mrp']*$_POST['qty'];



//print_r($sponser);
$cart=new Cart();
$carts=$cart->store($data);
if($carts)
{
    header("location:cart.php");
}
?>