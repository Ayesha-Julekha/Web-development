<?php
include_once("vendor/autoload.php");


define('UPLOADS', 'http://localhost/shop/uploads/');

//session_start();



